﻿using System;
namespace Atlas.Application.Enums
{
    public enum OrderStatus
    {
        Created    = 0,
        Delivering = 1,
        Canceled   = 2,
        Finished   = 3
    }
}
