﻿using FluentValidation;

namespace Atlas.Application.CQRS.Statistics.Queries.GetOverallBalanceOfClients
{
    public class GetOverallBalanceOfClientsQueryValidators : AbstractValidator<GetOverallBalanceOfClientsQuery>
    {
        public GetOverallBalanceOfClientsQueryValidators()
        {
        }
    }
}
