﻿using MediatR;

namespace Atlas.Application.CQRS.Statistics.Queries.GetOverallBalanceOfClients
{
    public class GetOverallBalanceOfClientsQuery : IRequest<long>
    {

    }
}
