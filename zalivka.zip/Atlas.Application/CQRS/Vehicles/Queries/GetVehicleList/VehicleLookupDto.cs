﻿using Atlas.Application.Common.Mappings;
using Atlas.Domain;
using AutoMapper;
using System;

namespace Atlas.Application.CQRS.Vehicles.Queries.GetVehicleList
{
    public class VehicleLookupDto : IMapWith<Vehicle>
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string RegistrationNumber { get; set; }

        public Guid VehicleTypeId { get; set; }

        public Guid StoreId { get; set; }

        public void Mapping(Profile profile)
        {
            profile.CreateMap<Vehicle, VehicleLookupDto>()
                .ForMember(dst => dst.Id, opt =>
                    opt.MapFrom(src => src.Id))
                .ForMember(dst => dst.Name, opt =>
                    opt.MapFrom(src => src.Name))
                .ForMember(dst => dst.RegistrationNumber, opt =>
                    opt.MapFrom(src => src.RegistrationNumber))
                .ForMember(dst => dst.VehicleTypeId, opt =>
                    opt.MapFrom(src => src.VehicleTypeId))
                .ForMember(dst => dst.StoreId, opt =>
                    opt.MapFrom(src => src.StoreId));
        }
    }
}
