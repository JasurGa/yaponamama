﻿using MediatR;

namespace Atlas.Application.CQRS.Consignments.Queries.GetConsignmentList
{
    public class GetConsignmentListQuery : IRequest<ConsignmentListVm>
    {

    }
}
