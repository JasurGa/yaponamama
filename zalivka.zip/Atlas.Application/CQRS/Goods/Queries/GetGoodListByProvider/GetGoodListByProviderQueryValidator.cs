﻿using System;
namespace Atlas.Application.CQRS.Goods.Queries.GetGoodListByProvider
{
    public class GetGoodListByProviderQueryValidator
    {
        public GetGoodListByProviderQueryValidator()
        {
        }
    }
}
