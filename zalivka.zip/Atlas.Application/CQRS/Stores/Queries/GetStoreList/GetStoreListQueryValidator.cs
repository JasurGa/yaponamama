﻿using FluentValidation;

namespace Atlas.Application.CQRS.Stores.Queries.GetStoreList
{
    public class GetStoreListQueryValidator : AbstractValidator<GetStoreListQuery>
    {
        public GetStoreListQueryValidator()
        {

        }
    }
}
